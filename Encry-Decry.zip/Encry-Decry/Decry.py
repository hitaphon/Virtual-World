from cryptography.fernet import Fernet
import sys

def load_key(key_file):
    try:
        with open(key_file, "rb") as file:
            return file.read()
    except Exception as e:
        print(f"Error loading key: {e}")
        sys.exit(1)

def decrypt_file(filename, key):
    try:
        fernet = Fernet(key)
        with open(filename, "rb") as file:
            encrypted_data = file.read()
        decrypted_data = fernet.decrypt(encrypted_data)
        with open(filename[:-10], "wb") as file:
            file.write(decrypted_data)
    except Exception as e:
        print(f"Error decrypting file: {e}")
        sys.exit(1)

def decrypt_file_with_key(filename, key_file):
    try:
        key = load_key(key_file)
        decrypt_file(filename, key)
    except Exception as e:
        print(f"Error decrypting file with key: {e}")
        sys.exit(1)

if __name__=='__main__':
    if len(sys.argv) == 2 and sys.argv[1] in ['-h', '--help']:
        print("Usage: python3 decry.py <filename> <key_filename>")
        sys.exit(0)

    if len(sys.argv) != 3:
        print("Usage: python3 decry.py <filename> <key_filename>")
        sys.exit(1)
    decrypt_file_with_key(sys.argv[1], sys.argv[2])
