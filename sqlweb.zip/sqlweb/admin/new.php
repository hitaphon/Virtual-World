<?php 
  require("../classes/auth.php");
  require("header.php");
  require("../classes/db.php");
  require("../classes/phpfix.php");
  require("../classes/picture.php");
  require("../classes/category.php");
?>
  <style>
    td { padding:10px;}

  </style>
  <div style='display:flex;justify-content:center;margin-top:50px;'>
  <form action="index.php" method="POST" enctype="multipart/form-data">
    <table style="border:1px solid black;">
    <tr><td>Title:</td><td> <input type="text" name="title" /></td></tr>
    <tr><td>File:</td><td> <input type="file" name="image"></td></tr>
    <tr><td colspan="2"><input style="width:100%;padding:5px;background" type="submit" name="Add" value="Add"></td></tr>
</table>
  </form>
</div>

<?php
  require("footer.php");

?>

