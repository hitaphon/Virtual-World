<?php 
  require("../classes/auth.php");
  require("header.php");
  require("../classes/db.php");
  require("../classes/phpfix.php");
  require("../classes/picture.php");
?>

<?php  
  $picture = Picture::delete($conn,(int)($_GET["id"]));
  header("Location: /admin/index.php");
?>

