<?php
require 'vendor/autoload.php';
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App();

$app->get('/assets/img/{filename}', function (Request $request, Response $response, array $args) {
    $imagePath = __DIR__ . '/assets/img/' . $args['filename'];
    if (file_exists($imagePath)) {
        $imageData = file_get_contents($imagePath);
        $response->write($imageData);
        return $response->withStatus(200)->withHeader('Content-Type', mime_content_type($imagePath));
    } else {
        return $response->withStatus(404);
    }
});

$app->get('/css/{filename}', function (Request $request, Response $response, array $args) {
    $cssPath = __DIR__ . '/css/' . $args['filename'];
    if (file_exists($cssPath)) {
        $cssData = file_get_contents($cssPath);
        $response->write($cssData);
        return $response->withStatus(200)->withHeader('Content-Type', 'text/css');
    } else {
        return $response->withStatus(404);
    }
});

$app->get('/tables', function (Request $request, Response $response, array $args) {
    $tablesPath = __DIR__ . '/ppt/tables.html';
    if (file_exists($tablesPath)) {
        $tablesData = file_get_contents($tablesPath);
        $response->write($tablesData);
        return $response->withStatus(200)->withHeader('Content-Type', 'text/html');
    } else {
        return $response->withStatus(404);
    }
});

$app->get('/', function (Request $request, Response $response, array $args) {
    $indexPath = __DIR__ . '/index.html';
    if (file_exists($indexPath)) {
        $indexData = file_get_contents($indexPath);
        $response->write($indexData);
        return $response->withStatus(200)->withHeader('Content-Type', 'text/html');
    } else {
        return $response->withStatus(404);
    }
});

$app->run();
