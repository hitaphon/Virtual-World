const express = require('express');
const path = require('path');
const app = express();


app.use('/assets/img', express.static(path.join(__dirname, 'assets', 'img')));
app.use('/css', express.static(path.join(__dirname, 'css')));
app.get('/tables', (req, res) => {
    res.status(200).sendFile(path.join(__dirname, 'ppt', 'tables.html'));
});

app.get('/', (req, res) => {
    res.status(200).sendFile(path.join(__dirname, 'index.html'));
});

app.listen(80, () => {
    console.log('Server is running on http://10.0.102.6:80');
});
